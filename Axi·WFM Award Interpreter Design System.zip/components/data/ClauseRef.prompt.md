One-liner: A hoverable clause citation — mono, dotted underline, dark tooltip explaining what the clause is and does. The auditability primitive.

```jsx
import { ClauseRef } from './ClauseRef'

// Single clause
<ClauseRef refText="cl. 15.2" purpose="sets the casual loading paid instead of paid leave" />

// Multi-clause with per-part explanation
<ClauseRef
  refText="cl. 21.1 / Sch B.2"
  parts={[
    { ref: 'cl. 21.1', title: 'Saturday penalty', purpose: 'sets the Saturday penalty rate' },
    { ref: 'Sch B.2', title: 'Casual rates', purpose: 'the casual column of the pay table' },
  ]}
/>

// In a tight last column, pin the tooltip right
<ClauseRef refText="cl. 26.4" align="right" style={{ fontSize: 11, color: 'var(--muted)' }} />
```

Notes
- Always mono — it signals "this is a citation, not a vibe". Never restyle it into body type.
- Use `align="right"` inside narrow table cells so the tooltip doesn't clip off-screen.
- The tooltip is the whole point: give every rate/loading its clause so the number is traceable.
