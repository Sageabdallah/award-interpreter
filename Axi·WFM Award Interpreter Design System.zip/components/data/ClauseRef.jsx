import React, { useState } from 'react'

/**
 * ClauseRef — a hoverable award-clause citation. Renders the ref in mono with a
 * dotted underline; on hover a dark tooltip explains what the clause IS and what
 * it DOES. This is the component that makes the product feel auditable: every
 * rate and loading points back to a named provision.
 *
 * Pass `parts` for multi-clause refs ("cl. 15.2 / Sch B") — each row shows the
 * clause, its title and its purpose. Or pass a single `purpose` string.
 */
export function ClauseRef({
  refText,
  parts = null,
  purpose = '',
  align = 'center',
  style,
}) {
  const [open, setOpen] = useState(false)
  if (!refText) return null

  const rows = parts && parts.length
    ? parts
    : [{ ref: refText, title: '', purpose }]

  const right = align === 'right'

  return (
    <span
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      style={{
        position: 'relative',
        cursor: 'help',
        fontFamily: 'var(--font-mono)',
        borderBottom: '1px dotted rgba(31,30,27,0.35)',
        ...style,
      }}
    >
      {refText}
      <span
        role="tooltip"
        style={{
          position: 'absolute',
          bottom: 'calc(100% + 9px)',
          left: right ? 'auto' : '50%',
          right: right ? '-6px' : 'auto',
          transform: right ? 'none' : 'translateX(-50%)',
          background: 'var(--ink)',
          color: 'var(--text-on-ink)',
          fontFamily: 'var(--font-body)',
          fontSize: 12,
          fontWeight: 400,
          lineHeight: 1.55,
          letterSpacing: 0,
          padding: '10px 13px',
          borderRadius: 'var(--radius-md)',
          width: 'max-content',
          maxWidth: 300,
          textAlign: 'left',
          whiteSpace: 'normal',
          opacity: open ? 1 : 0,
          visibility: open ? 'visible' : 'hidden',
          transition: 'opacity 0.13s ease',
          pointerEvents: 'none',
          zIndex: 60,
          boxShadow: 'var(--shadow-tip)',
        }}
      >
        {rows.map((row, i) => (
          <span key={i} style={{ display: 'block', marginTop: i ? 6 : 0 }}>
            <strong>{row.ref}</strong>
            {row.title ? ` — ${row.title}` : ' — referenced provision of the award'}
            {row.purpose && (
              <span style={{ display: 'block', color: 'rgba(245,241,234,0.72)', fontSize: 11.5 }}>
                {row.purpose}
              </span>
            )}
          </span>
        ))}
        <span
          style={{
            content: '""',
            position: 'absolute',
            top: '100%',
            left: right ? '85%' : '50%',
            transform: 'translateX(-50%)',
            borderWidth: 5,
            borderStyle: 'solid',
            borderColor: 'var(--ink) transparent transparent transparent',
          }}
        />
      </span>
    </span>
  )
}
