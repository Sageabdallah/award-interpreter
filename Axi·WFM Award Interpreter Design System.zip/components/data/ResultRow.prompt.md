One-liner: An expandable results-table row per employee; opens to a leader-dot pay breakdown, and turns red (total hidden) when there are validation errors.

```jsx
import { ResultRow } from './ResultRow'

const RESULTS_GRID = '1.55fr 1fr 1fr 1.35fr 0.95fr 1.1fr 1.2fr' // header must match

<ResultRow row={{
  employeeName: 'Sofia Marino', awardCode: 'MA000034', employeeLevel: 'RN Level 1',
  jobRole: 'Registered Nurse', totalHours: 76, employmentType: 'Permanent part-time',
  basePay: 38.42, extrasTotal: 84.10, totalCalculatedPay: 663.60, shiftCount: 6,
  breakdown: {
    ordinaryPay: 579.50,
    items: [{ label: 'Saturday penalty · 6 hrs', amount: 84.10 }],
    effectiveHourlyRate: 42.18, clauseRef: 'cl. 15.2',
  },
}} />

// Error row — impossible to skim past
<ResultRow row={{
  employeeName: 'Unmatched Employee', awardCode: 'Unmatched', employeeLevel: '—',
  jobRole: 'Kitchen hand', validationErrors: ['No award level matched — check the agreement file'],
}} />
```

Notes
- The `.thead` above the rows must use the same 7-column grid (`RESULTS_GRID`).
- Validation errors take priority: row + code + level render red and the total shows "—".
- Money is formatted en-AU AUD by default; pass `fmt` to override.
