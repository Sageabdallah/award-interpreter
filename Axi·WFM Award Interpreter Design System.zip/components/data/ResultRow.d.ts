export interface ResultBreakdownItem {
  label: string
  amount: number
}

export interface ResultBreakdown {
  ordinaryPay?: number
  /** Extra lines: penalties + allowances that applied this period. */
  items?: ResultBreakdownItem[]
  effectiveHourlyRate?: number
  /** Clause ref backing the base rate (string; wrap in <ClauseRef> for hover). */
  clauseRef?: string
}

export interface ResultRowData {
  employeeName: string
  awardCode: string
  employeeLevel: string
  jobRole: string
  totalHours?: number
  employmentType?: string
  basePay?: number
  extrasTotal?: number
  totalCalculatedPay?: number
  shiftCount?: number
  /** Non-empty ⇒ error state: row turns red, total hidden. */
  validationErrors?: string[]
  breakdown?: ResultBreakdown
}

export interface ResultRowProps {
  row: ResultRowData
  /** Controlled open state; omit to self-manage. */
  open?: boolean
  defaultOpen?: boolean
  onToggle?: (next: boolean) => void
  /** Currency formatter; defaults to en-AU AUD. */
  fmt?: (v: number) => string
}

export function ResultRow(props: ResultRowProps): JSX.Element
