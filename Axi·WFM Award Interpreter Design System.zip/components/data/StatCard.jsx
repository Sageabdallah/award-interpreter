import React from 'react'

/**
 * StatCard — a labelled headline metric. Icon well tinted by `accent`, a mono
 * uppercase label, a big Fraunces value and a muted caption. Stage 4 uses four
 * across; the validation-rows card uses accent="red" so a warning count never
 * reads as decorative.
 */
export function StatCard({ icon = null, label, value, caption, accent = 'ink' }) {
  const accentVar = {
    ink: 'var(--ink)',
    ochre: 'var(--ochre)',
    sage: 'var(--sage)',
    red: 'var(--red)',
  }[accent] || 'var(--ink)'

  return (
    <div style={{
      background: 'var(--card)',
      border: '1px solid var(--line)',
      borderRadius: 'var(--radius-2xl)',
      padding: '20px 20px 18px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 14 }}>
        <div style={{
          width: 30, height: 30, borderRadius: 'var(--radius-xs)', display: 'grid', placeItems: 'center',
          background: `color-mix(in srgb, ${accentVar} 12%, transparent)`, color: accentVar,
        }}>
          {icon}
        </div>
        <span style={{
          fontFamily: 'var(--font-mono)', fontSize: 'var(--th-size)', letterSpacing: 'var(--th-tracking)',
          textTransform: 'uppercase', color: 'var(--muted)',
        }}>
          {label}
        </span>
      </div>
      <div style={{ fontFamily: 'var(--font-serif)', fontSize: 30, fontWeight: 500, letterSpacing: '-0.01em', lineHeight: 1 }}>
        {value}
      </div>
      <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 8 }}>{caption}</div>
    </div>
  )
}
