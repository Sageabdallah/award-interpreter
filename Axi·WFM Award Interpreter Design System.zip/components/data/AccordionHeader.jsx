import React from 'react'

/**
 * AccordionHeader — the clickable header of an award-interpretation group.
 * Left: mono ochre award code + serif title + optional verified check.
 * Right: meta pills (levels, clause rows), a toned provenance badge, and a
 * chevron that reflects `open`. Wrap it and the table body in a card.
 */
export function AccordionHeader({
  code,
  title,
  matched = false,
  open = false,
  meta = [],
  provenance = null,
  onToggle,
  checkIcon = null,
  chevron = null,
}) {
  const provColor = provenance
    ? { sage: 'var(--sage)', ochre: 'var(--ochre)', neutral: 'var(--muted)' }[provenance.tone] || 'var(--ochre)'
    : null

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={onToggle}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onToggle?.() } }}
      style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
        padding: '4px 10px 12px', cursor: 'pointer', flexWrap: 'wrap',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, flexWrap: 'wrap', minWidth: 0 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12.5, color: 'var(--ochre)', fontWeight: 600 }}>{code}</span>
        <span style={{ fontFamily: 'var(--font-serif)', fontSize: 18, fontWeight: 500 }}>{title}</span>
        {matched && <span style={{ alignSelf: 'center', color: 'var(--sage)', display: 'inline-flex' }}>{checkIcon}</span>}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
        {meta.map((m, i) => (
          <span key={i} style={{
            display: 'inline-flex', alignItems: 'center', border: '1px solid var(--line)', borderRadius: 'var(--radius-pill)',
            padding: '5px 12px', background: 'var(--card)', fontSize: 11.5, color: 'var(--ink)',
          }}>
            {m}
          </span>
        ))}
        {provenance && (
          <span style={{
            display: 'inline-flex', alignItems: 'center', border: '1px solid',
            borderColor: `color-mix(in srgb, ${provColor} 45%, transparent)`, borderRadius: 'var(--radius-pill)',
            padding: '5px 12px', background: 'var(--card)', fontSize: 11.5, color: provColor,
          }}>
            {provenance.label}
          </span>
        )}
        <span style={{ color: 'var(--muted)', display: 'inline-flex', transform: open ? 'rotate(180deg)' : 'none', transition: 'transform var(--dur-med) ease' }}>
          {chevron || <span style={{ fontSize: 14 }}>⌄</span>}
        </span>
      </div>
    </div>
  )
}
