export interface StatCardProps {
  /** Icon element (Lucide), e.g. <Banknote size={16} strokeWidth={1.8} />. */
  icon?: React.ReactNode
  /** Mono uppercase label, e.g. "Base pay". */
  label: string
  /** Headline value (Fraunces) — already formatted (e.g. "$12,480.00", "148"). */
  value: React.ReactNode
  caption?: string
  /** Tints the icon well and signals meaning. red = warning counts that must not read as decorative. */
  accent?: 'ink' | 'ochre' | 'sage' | 'red'
}

/**
 * @startingPoint section="Data" subtitle="Labelled headline metric card" viewport="700x150"
 */
export function StatCard(props: StatCardProps): JSX.Element
