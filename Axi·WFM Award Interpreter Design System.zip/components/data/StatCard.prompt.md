One-liner: A labelled headline metric — tinted icon well, mono label, big Fraunces value, muted caption.

```jsx
import { StatCard } from './StatCard'
import { Clock, Banknote, Layers, AlertTriangle } from 'lucide-react'

<div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:16 }}>
  <StatCard icon={<Clock size={16} strokeWidth={1.8} />} label="Total hours" value="148" caption="across the uploaded timesheet" accent="ink" />
  <StatCard icon={<Banknote size={16} strokeWidth={1.8} />} label="Base pay" value="$12,480.00" caption="hours × matched base rate" accent="sage" />
  <StatCard icon={<Layers size={16} strokeWidth={1.8} />} label="Extras" value="$1,204.50" caption="allowances and penalties" accent="ochre" />
  <StatCard icon={<AlertTriangle size={16} strokeWidth={1.8} />} label="Validation rows" value="2" caption="employees needing review" accent="red" />
</div>
```

Notes
- Format currency `en-AU` before passing (`new Intl.NumberFormat('en-AU',{style:'currency',currency:'AUD'})`).
- Always use `accent="red"` on a warning/validation count so it reads as a signal, not decoration.
