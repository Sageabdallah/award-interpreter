import React, { useState } from 'react'

const audFmt = new Intl.NumberFormat('en-AU', { style: 'currency', currency: 'AUD' })
const defaultFmt = (v) => audFmt.format(Number(v) || 0)

const GRID = '1.55fr 1fr 1fr 1.35fr 0.95fr 1.1fr 1.2fr'

/**
 * ResultRow — one employee row in the Stage-4 results table, expandable to a
 * pay breakdown of leader-dot lines. When `row.validationErrors` is non-empty
 * the row turns red and shows the error instead of a total — impossible to skim
 * past. Pass a `fmt` to override currency formatting (defaults en-AU AUD).
 */
export function ResultRow({ row, open: controlledOpen, defaultOpen = false, onToggle, fmt = defaultFmt }) {
  const [uncontrolled, setUncontrolled] = useState(defaultOpen)
  const isOpen = controlledOpen != null ? controlledOpen : uncontrolled
  const toggle = () => { onToggle ? onToggle(!isOpen) : setUncontrolled((o) => !o) }

  const hasError = (row.validationErrors?.length || 0) > 0
  const errColor = hasError ? 'var(--red)' : 'var(--ink)'
  const b = row.breakdown || {}

  return (
    <div style={{ borderBottom: '1px solid var(--line)' }}>
      <div
        role="button"
        tabIndex={0}
        aria-expanded={isOpen}
        onClick={toggle}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle() } }}
        style={{
          display: 'grid', gridTemplateColumns: GRID, alignItems: 'center', gap: 14,
          padding: '16px 18px', cursor: 'pointer', borderRadius: 'var(--radius-lg)',
          transition: 'background var(--dur-fast) ease',
        }}
        onMouseEnter={(e) => { e.currentTarget.style.background = 'var(--hover-ink-row)' }}
        onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent' }}
      >
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 15, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{row.employeeName}</div>
          <div style={{ fontSize: 12.5, color: hasError ? 'var(--red)' : 'var(--muted)', marginTop: 2 }}>
            {hasError ? 'Validation error' : `${row.totalHours} hrs · ${row.employmentType || 'Employment unavailable'}`}
          </div>
        </div>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13.5, color: errColor }}>{row.awardCode}</span>
        <span style={{ fontSize: 13.5, color: errColor }}>{row.employeeLevel}</span>
        <span style={{ fontSize: 13.5 }}>{row.jobRole}</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13.5 }}>{fmt(row.basePay)}<span style={{ color: 'var(--muted)', fontSize: 11 }}>/hr</span></span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13.5 }}>{fmt(row.extrasTotal)}</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 14.5, fontWeight: 600, color: hasError ? 'var(--red)' : 'var(--ink)' }}>
          {hasError ? '—' : fmt(row.totalCalculatedPay)}
        </span>
      </div>

      {isOpen && (
        <div style={{ padding: '6px 18px 28px' }}>
          <div style={{ background: 'var(--paper)', border: '1px solid var(--line)', borderRadius: 'var(--radius-xl)', padding: 24 }}>
            {hasError && (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 22 }}>
                {row.validationErrors.map((err) => (
                  <span key={err} style={{
                    display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--red)',
                    background: 'var(--red-tint)', border: '1px solid var(--red-ring)', borderRadius: 'var(--radius-md)', padding: '9px 13px',
                  }}>
                    {err}
                  </span>
                ))}
              </div>
            )}
            <div style={{ display: 'grid', gridTemplateColumns: '1.35fr 1fr', gap: 30 }}>
              <div>
                <Label>Pay breakdown</Label>
                <Leader label="Ordinary pay" amt={fmt(b.ordinaryPay)} />
                {(b.items || []).map((it, i) => (
                  <Leader key={i} label={it.label} amt={fmt(it.amount)} />
                ))}
                <Leader label="Total calculated pay" amt={hasError ? '—' : fmt(row.totalCalculatedPay)} total />
                <Leader label="Entitled per hour, after loadings" amt={`${fmt(b.effectiveHourlyRate)}/hr`} />
              </div>
              <div>
                <Label>Match context</Label>
                <Leader label="Award code" amt={row.awardCode} />
                <Leader label="Employee level" amt={row.employeeLevel} />
                <Leader label="Job role" amt={row.jobRole} />
                <Leader label="Clause ref" amt={b.clauseRef || '—'} />
                <Leader label="Shift count" amt={String(row.shiftCount ?? '—')} />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function Label({ children }) {
  return (
    <div style={{
      fontFamily: 'var(--font-mono)', fontSize: 10.5, letterSpacing: '0.16em',
      textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 12,
    }}>
      {children}
    </div>
  )
}

function Leader({ label, amt, total = false }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'baseline', gap: 8, padding: '7px 0',
      ...(total ? { borderTop: '1px solid var(--line)', marginTop: 6, paddingTop: 12 } : null),
    }}>
      <span style={{ fontSize: total ? 14 : 13.5, fontWeight: total ? 600 : 400, color: 'var(--ink)' }}>{label}</span>
      <span style={{ flex: 1, borderBottom: '1px dotted rgba(31,30,27,0.3)', transform: 'translateY(-4px)' }} />
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: total ? 14 : 13, fontWeight: total ? 600 : 400, color: 'var(--ink)' }}>{amt}</span>
    </div>
  )
}
