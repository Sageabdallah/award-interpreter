One-liner: The clickable award-group header — code + title + verified check on the left, meta pills, provenance badge and chevron on the right.

```jsx
import { AccordionHeader } from './AccordionHeader'
import { BadgeCheck, ChevronDown } from 'lucide-react'

<div style={{ background:'var(--card)', border:'1px solid var(--line)', borderRadius:16, padding:'18px 18px 8px' }}>
  <AccordionHeader
    code="MA000034"
    title="Nurses Award 2020"
    matched
    open={open}
    meta={['22 levels', '184 clause rows']}
    provenance={{ label: 'Preloaded · Healthcare', tone: 'sage' }}
    onToggle={() => setOpen(o => !o)}
    checkIcon={<BadgeCheck size={15} strokeWidth={1.8} />}
    chevron={<ChevronDown size={16} strokeWidth={1.8} />}
  />
  {open && <AwardInterpretationTable ... />}
</div>
```

Notes
- Matched awards (a level named in an agreement) get `matched` and should sort to the top of the list.
- Provenance tone: `sage` = preloaded, `ochre` = uploaded or merged.
- Chevron rotates 180° via `open`; pass a Lucide ChevronDown.
