export interface AccordionProvenance {
  label: string
  tone: 'sage' | 'ochre' | 'neutral'
}

export interface AccordionHeaderProps {
  /** Award code, mono ochre (e.g. "MA000034"). */
  code: string
  /** Award title, serif (e.g. "Nurses Award 2020"). */
  title: string
  /** Show the sage verified check (a level in this award matched an agreement profile). */
  matched?: boolean
  open?: boolean
  /** Meta pills, e.g. ["22 levels", "184 clause rows"]. */
  meta?: React.ReactNode[]
  /** Toned provenance badge: preloaded (sage) / uploaded (ochre) / merged (ochre). */
  provenance?: AccordionProvenance | null
  onToggle?: () => void
  /** Lucide <BadgeCheck /> element for the matched marker. */
  checkIcon?: React.ReactNode
  /** Lucide <ChevronDown /> element; rotates when open. */
  chevron?: React.ReactNode
}

export function AccordionHeader(props: AccordionHeaderProps): JSX.Element
