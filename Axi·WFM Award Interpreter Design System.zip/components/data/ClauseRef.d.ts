export interface ClauseRefPart {
  /** The clause label, e.g. "cl. 15.2" or "Sch B". */
  ref: string
  /** The clause's title/heading, if known. */
  title?: string
  /** One line on what the clause does ("sets the casual loading paid instead of leave"). */
  purpose?: string
}

export interface ClauseRefProps {
  /** The visible citation text, e.g. "cl. 15.2 / Sch B". */
  refText: string
  /** Break a multi-clause ref into explained rows; overrides `purpose`. */
  parts?: ClauseRefPart[]
  /** Single-clause purpose line (used when `parts` is omitted). */
  purpose?: string
  /** Tooltip anchoring — "right" pins it to the right edge (use in narrow last columns). */
  align?: 'center' | 'right'
  style?: React.CSSProperties
}

export function ClauseRef(props: ClauseRefProps): JSX.Element
